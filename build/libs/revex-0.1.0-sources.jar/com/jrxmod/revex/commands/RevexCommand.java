package com.jrxmod.revex.commands;

import com.jrxmod.revex.Revex;
import com.jrxmod.revex.manager.BanManager;
import com.jrxmod.revex.util.DurationParser;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Map;

public class RevexCommand {

    private static final String LINE = "§8§m──────────────────────────§r";
    private static final String HEADER = "§8§m────§r §6§lREVEX§r §8§m────§r";
    private static final String BULLET = " §8» §r";

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(class_2170.method_9247("revex")
                    .requires(source -> source.method_9259(2))

                    // /revex status
                    .then(class_2170.method_9247("status")
                            .executes(ctx -> {
                                class_2168 source = ctx.getSource();
                                var cfg = Revex.getConfig();

                                source.method_9226(() -> class_2561.method_43470(HEADER), false);
                                source.method_9226(() -> class_2561.method_43470(
                                        BULLET + "§7Enabled: " + (cfg.enabled ? "§a✔ Yes" : "§c✘ No")), false);
                                source.method_9226(() -> class_2561.method_43470(
                                        BULLET + "§7Escalation ladder:"), false);

                                for (int i = 0; i < cfg.defaultEscalation.size(); i++) {
                                    int step = i + 1;
                                    String action = cfg.defaultEscalation.get(i);
                                    source.method_9226(() -> class_2561.method_43470(
                                            "   §8" + step + ". §f" + action), false);
                                }

                                source.method_9226(() -> class_2561.method_43470(
                                        BULLET + "§7Reset after: §e" + cfg.escalationResetTime), false);
                                source.method_9226(() -> class_2561.method_43470(
                                        BULLET + "§7Staff alerts: " + (cfg.staffAlerts ? "§a✔" : "§c✘")), false);
                                source.method_9226(() -> class_2561.method_43470(
                                        BULLET + "§7Discord: " + (cfg.discordWebhookEnabled ? "§a✔" : "§c✘")), false);
                                source.method_9226(() -> class_2561.method_43470(LINE), false);
                                return 1;
                            }))

                    // /revex bans
                    .then(class_2170.method_9247("bans")
                            .executes(ctx -> {
                                class_2168 source = ctx.getSource();
                                Map<String, BanManager.BanEntry> bans = Revex.getBanManager().getAllBans();

                                source.method_9226(() -> class_2561.method_43470(HEADER), false);
                                source.method_9226(() -> class_2561.method_43470(
                                        " §7Active bans §8(" + bans.size() + ")§7:"), false);
                                source.method_9226(() -> class_2561.method_43470(LINE), false);

                                if (bans.isEmpty()) {
                                    source.method_9226(() -> class_2561.method_43470(
                                            BULLET + "§aNo active bans."), false);
                                } else {
                                    bans.forEach((uuid, entry) -> {
                                        String remaining = entry.permanent ? "§cPermanent"
                                                : "§e" + DurationParser.format(entry.expiresAt - System.currentTimeMillis());
                                        source.method_9226(() -> class_2561.method_43470(
                                                BULLET + "§f" + entry.playerName + " §8— " +
                                                remaining + " §8— §7" + entry.reason), false);
                                    });
                                }
                                source.method_9226(() -> class_2561.method_43470(LINE), false);
                                return 1;
                            }))

                    // /revex ban <player> <duration> [reason]
                    .then(class_2170.method_9247("ban")
                            .then(class_2170.method_9244("player", StringArgumentType.word())
                                    .then(class_2170.method_9244("duration", StringArgumentType.word())
                                            .executes(ctx -> executeBan(ctx.getSource(),
                                                    StringArgumentType.getString(ctx, "player"),
                                                    StringArgumentType.getString(ctx, "duration"),
                                                    "Manual ban"))
                                            .then(class_2170.method_9244("reason", StringArgumentType.greedyString())
                                                    .executes(ctx -> executeBan(ctx.getSource(),
                                                            StringArgumentType.getString(ctx, "player"),
                                                            StringArgumentType.getString(ctx, "duration"),
                                                            StringArgumentType.getString(ctx, "reason")))))))

                    // /revex unban <player>
                    .then(class_2170.method_9247("unban")
                            .then(class_2170.method_9244("player", StringArgumentType.word())
                                    .executes(ctx -> {
                                        String name = StringArgumentType.getString(ctx, "player");
                                        class_2168 source = ctx.getSource();
                                        class_3222 target = source.method_9211()
                                                .method_3760().method_14566(name);

                                        // Try online player first, then search bans by name
                                        if (target != null) {
                                            boolean removed = Revex.getBanManager().unban(target.method_5667());
                                            if (removed) {
                                                source.method_9226(() -> class_2561.method_43470(
                                                        "§6[REVEX] §e" + name + " §fhas been §aunbanned§f."), false);
                                            } else {
                                                source.method_9213(class_2561.method_43470(
                                                        "§c[REVEX] §e" + name + " §fis not banned."));
                                            }
                                        } else {
                                            // Search by name in ban list
                                            Map<String, BanManager.BanEntry> bans = Revex.getBanManager().getAllBans();
                                            String foundUuid = null;
                                            for (var e : bans.entrySet()) {
                                                if (e.getValue().playerName.equalsIgnoreCase(name)) {
                                                    foundUuid = e.getKey();
                                                    break;
                                                }
                                            }
                                            if (foundUuid != null) {
                                                Revex.getBanManager().unban(java.util.UUID.fromString(foundUuid));
                                                source.method_9226(() -> class_2561.method_43470(
                                                        "§6[REVEX] §e" + name + " §fhas been §aunbanned§f."), false);
                                            } else {
                                                source.method_9213(class_2561.method_43470(
                                                        "§c[REVEX] §e" + name + " §fnot found in ban list."));
                                            }
                                        }
                                        return 1;
                                    })))

                    // /revex reload
                    .then(class_2170.method_9247("reload")
                            .executes(ctx -> {
                                class_2168 source = ctx.getSource();
                                Revex.reloadConfig();
                                source.method_9226(() -> class_2561.method_43470(
                                        "§6[REVEX] §fConfig §areloaded §fsuccessfully!"), false);
                                return 1;
                            }))
            );
        });
    }

    private static int executeBan(class_2168 source, String name, String duration, String reason) {
        class_3222 target = source.method_9211().method_3760().method_14566(name);

        if (target == null) {
            source.method_9213(class_2561.method_43470("§c[REVEX] §fPlayer not found: §e" + name));
            return 0;
        }

        if (duration.equalsIgnoreCase("perm") || duration.equalsIgnoreCase("permanent")) {
            Revex.getBanManager().permban(target.method_5667(), name, reason);
            BanManager.BanEntry entry = Revex.getBanManager().getBan(target.method_5667());
            target.field_13987.method_52396(Revex.getBanManager().buildBanScreen(entry));
            source.method_9226(() -> class_2561.method_43470(
                    "§6[REVEX] §e" + name + " §fpermanently banned. Reason: §7" + reason), false);
        } else {
            long durationMs = DurationParser.parseToMs(duration);
            if (durationMs <= 0) {
                source.method_9213(class_2561.method_43470(
                        "§c[REVEX] §fInvalid duration: §e" + duration +
                        " §8(use: 15m, 1h, 7d, perm)"));
                return 0;
            }
            Revex.getBanManager().tempban(target.method_5667(), name, durationMs, reason);
            BanManager.BanEntry entry = Revex.getBanManager().getBan(target.method_5667());
            target.field_13987.method_52396(Revex.getBanManager().buildBanScreen(entry));
            source.method_9226(() -> class_2561.method_43470(
                    "§6[REVEX] §e" + name + " §fbanned for §e" + duration + "§f. Reason: §7" + reason), false);
        }
        return 1;
    }
}
