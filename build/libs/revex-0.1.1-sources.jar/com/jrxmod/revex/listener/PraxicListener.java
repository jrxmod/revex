package com.jrxmod.revex.listener;

import com.jrxmod.praxic.api.PraxicViolationEvent;
import com.jrxmod.revex.Revex;
import com.jrxmod.revex.manager.BanManager;
import com.jrxmod.revex.manager.EscalationManager;
import com.jrxmod.revex.util.DurationParser;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class PraxicListener {

    public static void register() {
        PraxicViolationEvent.EVENT.register((player, checkName, violations, details, action) -> {
            if (!Revex.getConfig().enabled) return false;

            // Only intercept when PRAXIC resolves a punishable action (not just "flag")
            // Return false so PRAXIC handles flags normally
            if (action.equals("flag")) return false;

            // REVEX takes over — return true to cancel PRAXIC's built-in punishment
            handleViolation(player, checkName, violations, details);
            return true;
        });

        Revex.LOGGER.info("[REVEX] Listening to PRAXIC violation events.");
    }

    private static void handleViolation(class_3222 player, String checkName, int violations, String details) {
        EscalationManager escalation = Revex.getEscalationManager();
        BanManager banManager = Revex.getBanManager();

        String escalationAction = escalation.advanceAndGetAction(player.method_5667(), checkName);

        if (escalationAction.equals("warn")) {
            player.method_43496(class_2561.method_43470(
                    "§6[REVEX] §eWarning! §7Suspicious activity detected.\n" +
                    "§8» §7Check: §f" + checkName + " §8| §7Next offense will result in a temporary ban."
            ));
            sendStaffAlert(player, checkName, "warn");

        } else if (escalationAction.startsWith("tempban ")) {
            String durationStr = escalationAction.substring(8).trim();
            long durationMs = DurationParser.parseToMs(durationStr);

            if (durationMs <= 0) {
                Revex.LOGGER.error("[REVEX] Invalid tempban duration: {}", durationStr);
                return;
            }

            banManager.tempban(player.method_5667(), player.method_5477().getString(), durationMs, checkName);
            BanManager.BanEntry entry = banManager.getBan(player.method_5667());
            player.field_13987.method_52396(banManager.buildBanScreen(entry));

            sendStaffAlert(player, checkName, "tempban " + durationStr);
            Revex.LOGGER.warn("[REVEX] Player {} temp-banned for {} by {}.",
                    player.method_5477().getString(), durationStr, checkName);

        } else if (escalationAction.equals("ban")) {
            banManager.permban(player.method_5667(), player.method_5477().getString(), checkName);
            BanManager.BanEntry entry = banManager.getBan(player.method_5667());
            player.field_13987.method_52396(banManager.buildBanScreen(entry));

            sendStaffAlert(player, checkName, "permanent ban");
            Revex.LOGGER.warn("[REVEX] Player {} permanently banned by {}.",
                    player.method_5477().getString(), checkName);
        }
    }

    private static void sendStaffAlert(class_3222 player, String checkName, String action) {
        if (!Revex.getConfig().staffAlerts) return;
        if (player.method_5682() == null) return;

        class_2561 alert = class_2561.method_43470(
                "§6[REVEX] §bEnforcement §8» §e" + player.method_5477().getString() +
                " §8— §b" + checkName + " §8→ §f" + action
        );

        player.method_5682().method_3760().method_14571().stream()
                .filter(p -> p.method_5687(2))
                .forEach(p -> p.method_43496(alert));
    }
}
